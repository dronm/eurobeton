// Package services
package services

import (
	"context"
	"fmt"
	"sync"

	"github.com/dronm/eurobeton/models"

	crud "github.com/dronm/crudifier/v2"
	fields "github.com/dronm/crudifier/v2/fields"
	crudTypes "github.com/dronm/crudifier/v2/types"
	"github.com/dronm/ds/pgds"
	gmodels "github.com/dronm/gobizapp/models"
	gsrv "github.com/dronm/gobizapp/services"
	"github.com/dronm/session"
)

// for external upload fast access
type concreteTypeMapToProduction struct {
	mx     sync.RWMutex
	idList map[string]int // key is concrete description in external app, value is concrete ID in database
}

var ConcreteTypeMapToProductionList concreteTypeMapToProduction

// ConcreteTypeMapToProductionService is a service for ConcreteTypeMapToProduction database object.
type ConcreteTypeMapToProductionService struct {
	DB      *pgds.PgProvider
	Session session.Session
}

// NewConcreteTypeMapToProductionService is a service constructor.
func NewConcreteTypeMapToProductionService(db *pgds.PgProvider, sess session.Session) *ConcreteTypeMapToProductionService {
	return &ConcreteTypeMapToProductionService{DB: db, Session: sess}
}

// Insert inserts one row into models.ConcreteTypeMapToProduction
func (s *ConcreteTypeMapToProductionService) Insert(ctx context.Context, model models.ConcreteTypeMapToProduction) (map[string]any, error) {
	retFields, err := gsrv.InsertModel(ctx, s.DB, &model, nil)
	if err != nil {
		return nil, err
	}

	PublishEvent(ctx, s.Session, "ConcreteTypeMapToProduction.insert", retFields)

	return retFields, nil
}

func (s *ConcreteTypeMapToProductionService) Update(ctx context.Context, keyModel models.ConcreteTypeMapToProductionKey, model models.ConcreteTypeMapToProduction) (int64, error) {
	cnt, err := gsrv.UpdateModel(ctx, s.DB, keyModel, &model)
	if err != nil {
		return 0, err
	}

	PublishEvent(ctx, s.Session, "ConcreteTypeMapToProduction.update", keyModel)

	return cnt, nil
}

// Delete removes row from models.ConcreteTypeMapToProduction
func (s *ConcreteTypeMapToProductionService) Delete(ctx context.Context, keyModels []models.ConcreteTypeMapToProductionKey) (int64, error) {
	models := make([]crudTypes.DBModel, len(keyModels))
	for i, m := range keyModels {
		models[i] = m
	}
	cnt, err := gsrv.DeleteModel(ctx, s.DB, models, nil)
	if err != nil {
		return 0, err
	}

	PublishEvent(ctx, s.Session, "ConcreteTypeMapToProduction.delete", keyModels)

	return cnt, nil
}

// FetchDetail retrieves one row from models.ConcreteTypeMapToProduction
func (s *ConcreteTypeMapToProductionService) FetchDetail(ctx context.Context, id int) (*models.ConcreteTypeMapToProductionList, error) {
	model := models.ConcreteTypeMapToProductionList{}
	if err := gsrv.FetchModel(ctx, s.DB, &models.ConcreteTypeMapToProductionKey{ID: fields.NewFieldInt(int64(id), true, false)}, &model); err != nil {
		return nil, err
	}
	return &model, nil
}

// FetchList retrieves rows from models.ConcreteTypeMapToProduction. Returns two models: data and aggregates.
func (s *ConcreteTypeMapToProductionService) FetchList(ctx context.Context, params crud.CollectionParams) ([]*models.ConcreteTypeMapToProductionList, *gmodels.TotCount, error) {
	return gsrv.FetchCollectionModel(ctx, s.DB, &models.ConcreteTypeMapToProductionList{}, &gmodels.TotCount{}, params)
}

func (s *ConcreteTypeMapToProductionService) InitMapToProductionList(ctx context.Context) error {
	ConcreteTypeMapToProductionList.idList = make(map[string]int)

	poolConn, connID, err := s.DB.GetPrimary()
	if err != nil {
		return fmt.Errorf("GetPrimary(): %v", err)
	}
	defer s.DB.Release(poolConn, connID)
	conn := poolConn.Conn()

	rows, err := conn.Query(ctx,
		`SELECT 
			production_descr, 
			concrete_type_id 
		FROM concrete_type_map_to_production
		WHERE concrete_type_id IS NOT NULL AND production_descr IS NOT NULL`,
	)
	if err != nil {
		return fmt.Errorf("Query(): %v", err)
	}
	for rows.Next() {
		var productionDescr string
		var concreteTypeID int
		if err := rows.Scan(&productionDescr, &concreteTypeID); err != nil {
			return fmt.Errorf("Scan(): %v", err)
		}
		ConcreteTypeMapToProductionList.idList[productionDescr] = concreteTypeID
	}
	if err := rows.Err(); err != nil {
		return fmt.Errorf("Err(): %v", err)
	}

	return nil
}

func (s *ConcreteTypeMapToProductionService) Change(ctx context.Context) error {
	ConcreteTypeMapToProductionList.mx.Lock()
	defer ConcreteTypeMapToProductionList.mx.Unlock()
	return s.InitMapToProductionList(ctx)
}

// MapToProduction returns cementSilo ID from production description for a particular production site ID.
func (s *ConcreteTypeMapToProductionService) MapToProduction(ctx context.Context, productionDescr string) (int, error) {
    // Fast path: try read lock
    ConcreteTypeMapToProductionList.mx.RLock()
    if ConcreteTypeMapToProductionList.idList != nil {
        if id, ok := ConcreteTypeMapToProductionList.idList[productionDescr]; ok {
            ConcreteTypeMapToProductionList.mx.RUnlock()
            return id, nil
        }
    }
    ConcreteTypeMapToProductionList.mx.RUnlock()

    // Need to insert / initialize -> take write lock
    ConcreteTypeMapToProductionList.mx.Lock()
    defer ConcreteTypeMapToProductionList.mx.Unlock()

    // Initialize if map is nil
    if ConcreteTypeMapToProductionList.idList == nil {
        if err := s.InitMapToProductionList(ctx); err != nil {
            return 0, err
        }
    }

    // Re-check (another goroutine may have inserted while we were acquiring the lock)
    if id, ok := ConcreteTypeMapToProductionList.idList[productionDescr]; ok {
        return id, nil
    }

    // Not found → add new type (we hold the write lock while doing DB call to avoid duplicated DB inserts)
    poolConn, connID, err := s.DB.GetPrimary()
    if err != nil {
        return 0, fmt.Errorf("GetPrimary(): %v", err)
    }
    defer s.DB.Release(poolConn, connID)
    conn := poolConn.Conn()

    var id int
    if err := conn.QueryRow(ctx, `SELECT material_fact_consumptions_add_concrete_type($1)`, productionDescr).Scan(&id); err != nil {
        return 0, fmt.Errorf("SELECT material_fact_consumptions_add_concrete_type: %v", err)
    }

    // store into the map while still holding the write lock
    if ConcreteTypeMapToProductionList.idList == nil {
        ConcreteTypeMapToProductionList.idList = make(map[string]int)
    }
    ConcreteTypeMapToProductionList.idList[productionDescr] = id

    return id, nil
}

