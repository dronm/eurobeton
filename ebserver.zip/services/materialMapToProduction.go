// Package services
package services

import (
	"context"
	"fmt"
	"time"

	"github.com/dronm/eurobeton/models"

	crud "github.com/dronm/crudifier/v2"
	fields "github.com/dronm/crudifier/v2/fields"
	crudTypes "github.com/dronm/crudifier/v2/types"
	"github.com/dronm/ds/pgds"
	"github.com/dronm/session"

	gmodels "github.com/dronm/gobizapp/models"
	gsrv "github.com/dronm/gobizapp/services"
)

// MaterialMapToProductionService is a service for MaterialMapToProduction database object.
type MaterialMapToProductionService struct {
	DB      *pgds.PgProvider
	Session session.Session
}

// NewMaterialMapToProductionService is a service constructor.
func NewMaterialMapToProductionService(db *pgds.PgProvider, sess session.Session) *MaterialMapToProductionService {
	return &MaterialMapToProductionService{DB: db, Session: sess}
}

// Insert inserts one row into models.MaterialMapToProduction
func (s *MaterialMapToProductionService) Insert(ctx context.Context, model models.MaterialMapToProduction) (map[string]any, error) {
	retFields, err := gsrv.InsertModel(ctx, s.DB, &model, nil)
	if err != nil {
		return nil, err
	}

	PublishEvent(ctx, s.Session, "MaterialMapToProduction.Insert", retFields)

	return retFields, nil
}

func (s *MaterialMapToProductionService) Update(ctx context.Context, keyModel models.MaterialMapToProductionKey, model models.MaterialMapToProduction) (int64, error) {
	cnt, err := gsrv.UpdateModel(ctx, s.DB, keyModel, &model)
	if err != nil {
		return 0, err
	}

	PublishEvent(ctx, s.Session, "MaterialMapToProduction.Update", keyModel)

	return cnt, nil
}

// Delete removes row from models.MaterialMapToProduction
func (s *MaterialMapToProductionService) Delete(ctx context.Context, keyModels []models.MaterialMapToProductionKey) (int64, error) {
	models := make([]crudTypes.DBModel, len(keyModels))
	for i, m := range keyModels {
		models[i] = m
	}
	cnt, err := gsrv.DeleteModel(ctx, s.DB, models, nil)
	if err != nil {
		return 0, err
	}

	PublishEvent(ctx, s.Session, "MaterialMapToProduction.delete", keyModels)

	return cnt, nil
}

// FetchDetail retrieves one row from models.MaterialMapToProduction
func (s *MaterialMapToProductionService) FetchDetail(ctx context.Context, id int) (*models.MaterialMapToProductionList, error) {
	model := models.MaterialMapToProductionList{}
	if err := gsrv.FetchModel(ctx, s.DB, &models.MaterialMapToProductionKey{ID: fields.NewFieldInt(int64(id), true, false)}, &model); err != nil {
		return nil, err
	}
	return &model, nil
}

// FetchList retrieves rows from models.MaterialMapToProduction. Returns two models: data and aggregates.
func (s *MaterialMapToProductionService) FetchList(ctx context.Context, params crud.CollectionParams) ([]*models.MaterialMapToProductionList, *gmodels.TotCount, error) {
	return gsrv.FetchCollectionModel(ctx, s.DB, &models.MaterialMapToProductionList{}, &gmodels.TotCount{}, params)
}

func (s *MaterialMapToProductionService) Upsert(ctx context.Context, model models.MaterialMapToProduction, productionEnd time.Time) (map[string]any, error) {
	var retFields map[string]any

	poolConn, connID, err := s.DB.GetPrimary()
	if err != nil {
		return retFields, fmt.Errorf("GetPrimary(): %v", err)
	}
	defer s.DB.Release(poolConn, connID)
	conn := poolConn.Conn()

	var id int
	if err := conn.QueryRow(ctx,
		`SELECT material_fact_consumptions_add_material($1::int, $2::text, $3)`,
		model.ProductionSiteID.GetValue(),
		model.ProductionDescr.GetValue(),
		productionEnd,
	).Scan(&id); err != nil {
		return retFields, fmt.Errorf("QueryRow(): %v", err)
	}
	retFields = map[string]any{"id": id}

	if s.Session != nil {
		PublishEvent(ctx, s.Session, "MaterialMapToProduction.Insert", retFields)
	}

	return retFields, nil
}
